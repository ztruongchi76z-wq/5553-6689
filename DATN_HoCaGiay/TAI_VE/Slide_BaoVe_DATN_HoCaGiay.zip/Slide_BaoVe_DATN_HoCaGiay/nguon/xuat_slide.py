# -*- coding: utf-8 -*-
"""Xuất slide: PNG từng slide, PDF, PPTX dạng ảnh có ghi chú, ghi chú thuyết trình.

python3 xuat_slide.py <thư mục Slide_BaoVe_DATN_HoCaGiay>
"""
import html
import json
import os
import re
import sys

from playwright.sync_api import sync_playwright
from pptx import Presentation
from pptx.util import Emu

GOC = os.path.abspath(sys.argv[1])
NG = os.path.join(GOC, 'nguon')
CHROME = '/opt/pw-browsers/chromium-1194/chrome-linux/chrome'


def main():
    od = json.load(open(os.path.join(NG, 'project', 'deck.json'), encoding='utf-8'))['order']
    png_dir = os.path.join(GOC, 'png')
    for f in os.listdir(png_dir):
        os.remove(os.path.join(png_dir, f))
    with sync_playwright() as p:
        b = p.chromium.launch(executable_path=CHROME)
        pg = b.new_page(viewport={'width': 1920, 'height': 1080})
        pg.goto('file://' + os.path.join(NG, 'xem_offline.html'))
        pg.wait_for_load_state('networkidle')
        pg.evaluate('document.fonts.ready')
        tran = pg.evaluate('''() => [...document.querySelectorAll('section')].map(s => {
            const r = s.getBoundingClientRect(); let m = 0, ten = '';
            for (const e of s.querySelectorAll('*')) {
              if (e.closest('aside')) continue;
              const st = getComputedStyle(e);
              if (st.position === 'absolute' && st.bottom === '64px') continue;
              if (e.closest('div[style*="bottom:64px"]')) continue;
              const q = e.getBoundingClientRect();
              if (q.height > 0 && q.bottom - r.top > m) { m = q.bottom - r.top; ten = e.tagName + ':' + (e.textContent || '').slice(0, 40); }
            }
            return [s.id, Math.round(m), ten];
        })''')
        for sid, m, ten in tran:
            if m > 1080 - 110:
                print('CẢNH BÁO tràn:', sid, m, ten)
        anh = []
        for k, sid in enumerate(od, 1):
            el = pg.locator('section#' + sid)
            ten = os.path.join(png_dir, '%02d_%s.png' % (k, sid))
            el.screenshot(path=ten)
            anh.append(ten)
        pg.emulate_media(media='print')
        pg.pdf(path=os.path.join(GOC, 'Slide_BaoVe_DATN_HoCaGiay.pdf'), width='1920px', height='1080px',
               print_background=True, prefer_css_page_size=True)
        ghi = pg.evaluate('''() => [...document.querySelectorAll('section')].map(s => {
            const a = s.querySelector('aside'); const h = s.querySelector('h1, h2');
            return [s.id, h ? h.textContent.trim() : '', a ? a.textContent.trim() : ''];
        })''')
        b.close()
    gm = {sid: (t, a) for sid, t, a in ghi}
    prs = Presentation()
    prs.slide_width, prs.slide_height = Emu(12192000), Emu(6858000)
    lines = ['GHI CHÚ THUYẾT TRÌNH – Bảo vệ ĐATN – Hồ chứa nước Cà Giây (bản 12/10/2026)', '']
    for k, (sid, f) in enumerate(zip(od, anh), 1):
        s = prs.slides.add_slide(prs.slide_layouts[6])
        s.shapes.add_picture(f, 0, 0, width=prs.slide_width, height=prs.slide_height)
        t, a = gm[sid]
        s.notes_slide.notes_text_frame.text = a
        lines += ['Slide %d – %s' % (k, t if sid != 'du-phong' else 'Dự phòng: ' + t), a, '']
    prs.save(os.path.join(GOC, 'Slide_BaoVe_DATN_HoCaGiay_anh.pptx'))
    open(os.path.join(GOC, 'ghi_chu_thuyet_trinh.txt'), 'w', encoding='utf-8').write('\n'.join(lines))
    print('Xong:', len(anh), 'slide')


if __name__ == '__main__':
    main()
